(function () {
  // =====================================================
  // ISI DATA DI SINI
  // Di Weebly, gambar harus berupa alamat lengkap (https://...),
  // bukan nama file. Upload gambar ke Weebly lalu salin alamatnya.
  // =====================================================

  // Logo (boleh kosong)
  var LOGO = "";

  // nama   : nama varian rasa
  // gambar : alamat gambar es teh (boleh kosong)
  // harga  : misalnya "Rp 10.000" (boleh kosong)
  var MENU = [
    { nama: "Teh Original",          gambar: "", harga: "" },
    { nama: "Teh Kampul",            gambar: "", harga: "" },
    { nama: "Lychee Tea",            gambar: "", harga: "" },
    { nama: "Jasmine Tea",           gambar: "", harga: "" },
    { nama: "Passion Fruit Tea",     gambar: "", harga: "" },
    { nama: "Blueberry Tea",         gambar: "", harga: "" },
    { nama: "Thai Tea",              gambar: "", harga: "" },
    { nama: "Green Tea",             gambar: "", harga: "" },
    { nama: "Macchiatto ChocoMelt",  gambar: "", harga: "" },
    { nama: "Macchiatto Cappuccino", gambar: "", harga: "" },
    { nama: "Macchiatto RedVelvet",  gambar: "", harga: "" },
    { nama: "Macchiatto Taro",       gambar: "", harga: "" },
    { nama: "Milk Tea",              gambar: "", harga: "" },
    { nama: "Lychee Fruit",          gambar: "", harga: "" },
    { nama: "Mango Fruit",           gambar: "", harga: "" },
    { nama: "Grape Fruit",           gambar: "", harga: "" },
    { nama: "Strawberry Fruit",      gambar: "", harga: "" }
  ];

  // nama       : nama anggota
  // keterangan : peran, NIM, atau apa saja (boleh kosong)
  // foto       : alamat foto (boleh kosong, nanti tampil huruf inisial)
  var ANGGOTA = [
    { nama: "Anggota 1", keterangan: "", foto: "" },
    { nama: "Anggota 2", keterangan: "", foto: "" },
    { nama: "Anggota 3", keterangan: "", foto: "" },
    { nama: "Anggota 4", keterangan: "", foto: "" },
    { nama: "Anggota 5", keterangan: "", foto: "" }
  ];

  // =====================================================
  // KODE (tidak perlu diubah)
  // =====================================================
  function el(tag, kelas, teks) {
    var e = document.createElement(tag);
    if (kelas) e.className = kelas;
    if (teks) e.textContent = teks;
    return e;
  }

  // Area geser horizontal: bar kustom yang bisa diseret + seret isi dengan mouse
  function pasangGeser(p) {
    var gulir = p.querySelector(".etd-gulir");
    var bar = p.querySelector(".etd-bar");
    var thumb = p.querySelector(".etd-thumb");
    if (!gulir || !bar || !thumb) return;
    p.classList.add("etd-js");

    function perbarui() {
      var lebar = gulir.scrollWidth, tampak = gulir.clientWidth;
      if (lebar <= tampak + 1) { bar.style.visibility = "hidden"; return; }
      bar.style.visibility = "visible";
      var trek = bar.clientWidth;
      var tw = Math.max(40, trek * tampak / lebar);
      var maks = lebar - tampak;
      thumb.style.width = tw + "px";
      thumb.style.left = (gulir.scrollLeft / maks) * (trek - tw) + "px";
    }
    gulir.addEventListener("scroll", perbarui, { passive: true });
    window.addEventListener("resize", perbarui);
    if (window.ResizeObserver) {
      var ro = new ResizeObserver(perbarui);
      ro.observe(gulir);
      if (gulir.firstElementChild) ro.observe(gulir.firstElementChild);
    }
    perbarui();

    // Seret thumb
    thumb.addEventListener("pointerdown", function (e) {
      e.preventDefault();
      e.stopPropagation();
      var x0 = e.clientX, kiri0 = gulir.scrollLeft;
      var trek = bar.clientWidth - thumb.offsetWidth;
      var maks = gulir.scrollWidth - gulir.clientWidth;
      thumb.setPointerCapture(e.pointerId);
      function geser(ev) { gulir.scrollLeft = kiri0 + (ev.clientX - x0) * maks / trek; }
      function lepas() {
        thumb.removeEventListener("pointermove", geser);
        thumb.removeEventListener("pointerup", lepas);
        thumb.removeEventListener("pointercancel", lepas);
      }
      thumb.addEventListener("pointermove", geser);
      thumb.addEventListener("pointerup", lepas);
      thumb.addEventListener("pointercancel", lepas);
    });

    // Klik di jalur bar untuk melompat
    bar.addEventListener("pointerdown", function (e) {
      if (e.target === thumb) return;
      var r = bar.getBoundingClientRect();
      var trek = bar.clientWidth - thumb.offsetWidth;
      var rasio = Math.min(1, Math.max(0, (e.clientX - r.left - thumb.offsetWidth / 2) / trek));
      gulir.scrollLeft = rasio * (gulir.scrollWidth - gulir.clientWidth);
    });

    // Seret isi dengan mouse (layar sentuh sudah bisa digeser bawaan)
    var seret = false, x0 = 0, kiri0 = 0, bergerak = false;
    gulir.addEventListener("mousedown", function (e) {
      if (e.button !== 0) return;
      seret = true; bergerak = false; x0 = e.pageX; kiri0 = gulir.scrollLeft;
    });
    window.addEventListener("mousemove", function (e) {
      if (!seret) return;
      var dx = e.pageX - x0;
      if (!bergerak && Math.abs(dx) < 4) return;
      bergerak = true;
      gulir.classList.add("menyeret");
      gulir.scrollLeft = kiri0 - dx;
    });
    window.addEventListener("mouseup", function () {
      seret = false;
      gulir.classList.remove("menyeret");
    });
    gulir.addEventListener("dragstart", function (e) { e.preventDefault(); });
  }

  function init() {
    var root = document.getElementById("etd");
    if (!root) return;

    // Logo
    if (LOGO) {
      var lh = document.getElementById("etd-logo-home");
      var ln = document.getElementById("etd-logo-nav");
      if (lh) { lh.src = LOGO; lh.style.display = "block"; }
      if (ln) { ln.src = LOGO; ln.style.display = "block"; }
    }

    // Menu dan harga
    var grid = document.getElementById("etd-grid-es");
    if (grid) {
      MENU.forEach(function (m, i) {
        var ganjilTerakhir = (MENU.length % 2 === 1 && i === MENU.length - 1);
        var kartu = el("div", "etd-es" + (ganjilTerakhir ? " etd-tengah" : ""));
        var foto = el("div", "etd-foto");
        if (m.gambar) {
          var img = el("img");
          img.src = m.gambar;
          img.alt = m.nama;
          img.loading = "lazy";
          foto.appendChild(img);
        } else {
          foto.appendChild(el("div", "etd-gelas"));
        }
        var isi = el("div", "etd-es-isi");
        isi.appendChild(el("h3", "", m.nama));
        isi.appendChild(el("div", "etd-rp" + (m.harga ? "" : " kosong"), m.harga || "Rp -"));
        kartu.appendChild(foto);
        kartu.appendChild(isi);
        grid.appendChild(kartu);
      });
    }

    // Kelompok 5
    var tim = document.getElementById("etd-tim");
    if (tim) {
      ANGGOTA.forEach(function (a) {
        var k = el("div", "etd-anggota");
        var av = el("div", "etd-avatar");
        if (a.foto) {
          var im = el("img");
          im.src = a.foto;
          im.alt = a.nama;
          av.appendChild(im);
        } else {
          av.textContent = (a.nama || "?").trim().charAt(0).toUpperCase();
        }
        k.appendChild(av);
        k.appendChild(el("h3", "", a.nama));
        if (a.keterangan) k.appendChild(el("p", "", a.keterangan));
        tim.appendChild(k);
      });
    }

    // Aktifkan area geser horizontal (setelah isi dirender)
    Array.prototype.forEach.call(root.querySelectorAll(".etd-pembungkus"), pasangGeser);

    // Scroll halus ke bagian yang dituju
    var kurangiGerak = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    var pemicu = root.querySelectorAll("a[data-target]");
    Array.prototype.forEach.call(pemicu, function (a) {
      a.addEventListener("click", function (e) {
        var tujuan = document.getElementById(a.getAttribute("data-target"));
        if (!tujuan) return;
        e.preventDefault();
        tujuan.scrollIntoView({ behavior: kurangiGerak ? "auto" : "smooth", block: "start" });
      });
    });

    // Tandai tombol navbar sesuai bagian yang sedang terlihat
    var tombol = root.querySelectorAll(".etd-menu a");
    var ids = ["etd-home", "etd-info", "etd-harga", "etd-kelompok"];
    function tandai() {
      var aktif = ids[0];
      ids.forEach(function (id) {
        var s = document.getElementById(id);
        if (s && s.getBoundingClientRect().top <= 140) aktif = id;
      });
      var akhir = document.getElementById("etd-kelompok");
      if (akhir && akhir.getBoundingClientRect().bottom <= window.innerHeight + 4) aktif = "etd-kelompok";
      Array.prototype.forEach.call(tombol, function (t) {
        if (t.getAttribute("data-target") === aktif) t.classList.add("aktif");
        else t.classList.remove("aktif");
      });
    }
    window.addEventListener("scroll", tandai, { passive: true });
    window.addEventListener("resize", tandai);
    tandai();
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
